import com.fishtracker.motionv4.MotionAnalyzer;

public class MotionAnalyzerTest {
    private static final int W = 115, H = 95;
    private static final int BACKGROUND = 0x243044;
    private static int[] frame(int cx, int cy) {
        int[] data = new int[W * H];
        for (int y=0; y<H; y++) for (int x=0; x<W; x++) {
            // Distinct static background texture to avoid oversimplifying the test.
            int noise = ((x * 13 + y * 7) % 14);
            data[y*W+x] = ((36+noise)<<16) | ((48+noise)<<8) | (68+noise);
            if ((x-cx)*(x-cx) + (y-cy)*(y-cy) <= 36) data[y*W+x] = 0xe5c94b;
        }
        return data;
    }
    public static void main(String[] args) {
        boolean[] region = new boolean[W * H];
        for (int y=3; y<H-3; y++) for (int x=3; x<W-3; x++) region[y*W+x]=true;
        MotionAnalyzer tracker = new MotionAnalyzer(W, H, 3, region, 1);
        MotionAnalyzer.Result last = null;
        for (int t=0; t<32; t++) {
            int x = 20 + t * 2;
            last = tracker.update(frame(x, 44), 1_000_000_000L + t*100_000_000L);
            if(t == 9 && last.state != MotionAnalyzer.State.LEARNING) throw new AssertionError("Warmup state");
            if(t > 18) System.out.println(t+" "+last.state+" speed="+Math.round(last.speedPixelsPerSecond)+" px/s");
        }
        if (last == null || last.state != MotionAnalyzer.State.TRACKING) throw new AssertionError("No tracked fish");
        if (last.speedPixelsPerSecond < 30 || last.speedPixelsPerSecond > 105) {
            throw new AssertionError("Expected approx 60 px/s, got " + last.speedPixelsPerSecond);
        }
        System.out.println("MotionAnalyzer synthetic moving-fish test PASSED");
    }
}

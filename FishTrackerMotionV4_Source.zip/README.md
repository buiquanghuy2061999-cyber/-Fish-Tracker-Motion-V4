# Fish Tracker Motion V4 (Android)

Thiết kế cho Black Shark 5 / Android 12 (MIUI 13), không cần máy tính để biên dịch nếu dùng GitHub Actions.

## Tính năng

- Chụp màn hình bằng **MediaProjection** sau khi người dùng đồng ý.
- Nút nổi **✎ VẼ VÙNG** nhỏ cho phép chuyển sang game **trước khi khoanh vùng**.
- Dùng ngón tay vẽ tự do vùng kín; chỉ các điểm bên **trong** nét vẽ mới được đưa vào phân tích. Nút **VẼ LẠI**, **XONG**, **HỦY**.
- Đo chuyển động bằng phân biệt vật thể chuyển động với nền (màu RGB + sự thay đổi giữa 2 khung hình), tìm vùng chuyển động và bám tâm vùng này.
- Tốc độ ước tính theo **px/s**; HUD lớn, tương phản cao; báo **Đang học nền**, **Chưa phát hiện chuyển động cá**, **Đang theo dõi**.
- HUD dùng FLAG_NOT_TOUCHABLE và alpha 0.74 (dưới giới hạn 0.8 của Android 12) để không chặn thao tác game.
- Điều chỉnh độ nhạy Thấp / Vừa / Cao; nút **VẼ LẠI VÙNG ĐO** trong ứng dụng; đổi hướng màn hình thì phải chọn lại vùng.
- App ID mới `com.fishtracker.motionv4`, không ghi đè V2/V3.

## Hạn chế / không bảo đảm

- Đây là thuật toán **ước tính tốc độ chuyển động hình ảnh**, không nhận dạng chính xác một loài hoặc một cá thể cá, không có đơn vị m/s thực địa.
- Có thể sai khi nhiều cá cùng bơi, nền chuyển động mạnh, hiệu ứng ánh sáng hoặc cá rất nhỏ/màu gần nền; báo không thấy khi cá đứng yên hoặc nằm ngoài vùng vẽ.
- Tính năng chỉ được kiểm tra thuật toán với dữ liệu mô phỏng bằng Java, **chưa biên dịch APK hay thử trên Black Shark 5 thực tế**.
- Có thể cần cấp thêm quyền cửa sổ nổi trong cài đặt MIUI; mỗi lần bắt đầu capture cần đồng ý ghi màn hình.

## Dùng GitHub Actions trên điện thoại

Trong repo cũ `FishTrackerMotionV2`:

1. Tải `FishTrackerMotionV4_Source.zip` lên thư mục gốc của repo qua **Add file → Upload files**.
2. Vào `.github/workflows/import-and-build.yml`, nhấn bút chì và **thay toàn bộ nội dung** bằng nội dung tệp `FishTrackerMotionV4_import-and-build.yml` được phát kèm.
3. Nhấn **Commit changes**, mở tab **Actions**, chọn run mới có tên `Import and Build Fish Tracker V4`.
4. Khi run tích xanh, vào **Artifacts → FishTrackerMotionV4-APK** và tải file APK bên trong ZIP artifact.
5. Cài APK (package mới), mở app, cấp quyền overlay và ghi màn hình. **Mở game**, nhấn nút nổi **VẼ VÙNG**, vẽ khoanh vùng, nhấn XONG.

Lưu ý: Workflow `build-apk.yml` nằm bên trong ZIP dùng cho trường hợp **đã giải nén toàn bộ mã nguồn vào repository**; khi chỉ upload ZIP cần dùng workflow importer riêng ở bước 2.

## Kiểm thử thuật toán (trên máy tính/JDK)

```bash
mkdir -p /tmp/fish-v4-test
javac -d /tmp/fish-v4-test \
  app/src/main/java/com/fishtracker/motionv4/MotionAnalyzer.java \
  tests/MotionAnalyzerTest.java
java -cp /tmp/fish-v4-test MotionAnalyzerTest
```

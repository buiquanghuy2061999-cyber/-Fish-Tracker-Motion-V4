package com.fishtracker.motionv4;

import java.util.Arrays;

/**
 * Android-independent foreground-object centroid tracker.
 * Background subtraction is preferable to whole-frame translation when the
 * game background is static and a small fish moves across it.
 * Output is ESTIMATED SCREEN PIXELS/SECOND, not calibrated world speed.
 */
public final class MotionAnalyzer {
    public enum State { LEARNING, TRACKING, SEARCHING }

    public static final class Result {
        public final State state;
        public final double speedPixelsPerSecond;
        public final double x;
        public final double y;
        public final int objectPixels;
        Result(State state, double speed, double x, double y, int objectPixels) {
            this.state = state;
            this.speedPixelsPerSecond = speed;
            this.x = x;
            this.y = y;
            this.objectPixels = objectPixels;
        }
    }

    private final int width, height, length, step, sensitivity;
    private final boolean[] inside;
    private final float[] bgR, bgG, bgB;
    private final boolean[] moving, changed, clean, visited;
    private final int[] previousRgb;
    private final int[] queue;
    private int warmFrames = 0;
    private double lastX = Double.NaN, lastY = Double.NaN, speed = 0;
    private long lastSeenNs = 0;
    private int missingFrames = 0;
    private final int visible;

    public MotionAnalyzer(int width, int height, int step, boolean[] inside, int sensitivity) {
        if (width <= 0 || height <= 0 || step <= 0 || inside.length != width * height) {
            throw new IllegalArgumentException("Invalid image grid");
        }
        this.width = width;
        this.height = height;
        this.step = step;
        this.length = width * height;
        this.inside = inside.clone();
        this.sensitivity = Math.max(0, Math.min(2, sensitivity));
        bgR = new float[length]; bgG = new float[length]; bgB = new float[length];
        moving = new boolean[length]; changed = new boolean[length]; clean = new boolean[length]; visited = new boolean[length];
        previousRgb = new int[length];
        queue = new int[length];
        int count = 0;
        for (boolean b : inside) if (b) count++;
        visible = count;
    }

    public Result update(int[] rgb, long timestampNs) {
        if (rgb.length != length) throw new IllegalArgumentException("Frame size mismatch");
        if (visible < 15) return new Result(State.SEARCHING, 0, Double.NaN, Double.NaN, 0);
        int threshold = sensitivity == 2 ? 21 : sensitivity == 0 ? 46 : 32;
        boolean warming = warmFrames < 14;
        for (int i = 0; i < length; i++) {
            if (!inside[i]) { moving[i] = false; changed[i] = false; continue; }
            int value = rgb[i];
            int r = (value >>> 16) & 255, g = (value >>> 8) & 255, b = value & 255;
            if (warmFrames == 0) {
                bgR[i] = r; bgG[i] = g; bgB[i] = b;
                moving[i] = false;
                changed[i] = false;
                previousRgb[i] = value;
                continue;
            }
            int diff = Math.max(Math.abs(r - Math.round(bgR[i])),
                         Math.max(Math.abs(g - Math.round(bgG[i])), Math.abs(b - Math.round(bgB[i]))));
            moving[i] = !warming && diff >= threshold;
            int old = previousRgb[i];
            int temporal = Math.max(Math.abs(r - ((old >>> 16) & 255)),
                     Math.max(Math.abs(g - ((old >>> 8) & 255)), Math.abs(b - (old & 255))));
            changed[i] = !warming && temporal >= 14;
            previousRgb[i] = value;
            // Do not quickly incorporate the moving object into the background.
            float learn = warming ? 0.17f : moving[i] ? 0.002f : 0.025f;
            bgR[i] += learn * (r - bgR[i]);
            bgG[i] += learn * (g - bgG[i]);
            bgB[i] += learn * (b - bgB[i]);
        }
        warmFrames++;
        if (warming) {
            return new Result(State.LEARNING, 0, Double.NaN, Double.NaN, 0);
        }

        // Remove isolated single-pixel differences before component labeling.
        Arrays.fill(clean, false);
        for (int y = 1; y < height - 1; y++) {
            for (int x = 1; x < width - 1; x++) {
                int k = y * width + x;
                if (!moving[k]) continue;
                int adjacent = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        if (dx == 0 && dy == 0) continue;
                        if (moving[k + dy * width + dx]) adjacent++;
                    }
                }
                clean[k] = adjacent >= 2;
            }
        }
        Arrays.fill(visited, false);
        double chosenX = Double.NaN, chosenY = Double.NaN;
        int chosenArea = 0;
        double chosenScore = Double.POSITIVE_INFINITY;
        final int minArea = Math.max(4, visible / 27000);
        final int maxArea = Math.max(minArea + 1, (int) (visible * 0.42));
        boolean trackedBefore = !Double.isNaN(lastX);

        for (int seed = 0; seed < length; seed++) {
            if (!clean[seed] || visited[seed]) continue;
            int read = 0, size = 1;
            queue[0] = seed;
            visited[seed] = true;
            int area = 0, fresh = 0;
            double freshX = 0, freshY = 0;
            while (read < size) {
                int k = queue[read++];
                int x = k % width, y = k / width;
                area++;
                if (changed[k]) { fresh++; freshX += x; freshY += y; }
                for (int dy = -1; dy <= 1; dy++) {
                    int ny = y + dy;
                    if (ny < 0 || ny >= height) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = x + dx;
                        if (nx < 0 || nx >= width || (dx == 0 && dy == 0)) continue;
                        int neighbor = ny * width + nx;
                        if (clean[neighbor] && !visited[neighbor]) {
                            visited[neighbor] = true;
                            queue[size++] = neighbor;
                        }
                    }
                }
            }
            if (area < minArea || area > maxArea || fresh < Math.max(2, area / 18)) continue;
            // The changing subset rejects static foreground ghosts left by a moving fish.
            double x = freshX / fresh, y = freshY / fresh;
            double score;
            if (!trackedBefore) {
                score = -area;
            } else {
                // Prefer the nearest plausible object; size is a tiebreaker.
                double dx = x - lastX, dy = y - lastY;
                double d2 = dx * dx + dy * dy;
                score = d2 - Math.min(area, 100) * 0.05;
            }
            if (score < chosenScore) {
                chosenScore = score; chosenX = x; chosenY = y; chosenArea = area;
            }
        }
        if (chosenArea == 0) {
            missingFrames++;
            if (missingFrames >= 3) {
                speed = 0; lastX = Double.NaN; lastY = Double.NaN; lastSeenNs = 0;
            }
            return new Result(State.SEARCHING, 0, Double.NaN, Double.NaN, 0);
        }

        if (trackedBefore && lastSeenNs != 0) {
            double dt = (timestampNs - lastSeenNs) / 1_000_000_000.0;
            double distance = Math.hypot(chosenX - lastX, chosenY - lastY) * step;
            // Large jumps usually mean a different blob was selected.
            double diagonal = Math.hypot(width, height) * step;
            if (dt > 0.035 && dt < 0.8 && distance < Math.max(40, diagonal * 0.22)) {
                double instant = distance < step * 0.85 ? 0 : distance / dt;
                speed = Math.min(1800, speed * 0.62 + instant * 0.38);
            } else {
                speed = 0;
            }
        } else {
            speed = 0;
        }
        lastX = chosenX; lastY = chosenY; lastSeenNs = timestampNs; missingFrames = 0;
        return new Result(State.TRACKING, speed, chosenX * step, chosenY * step, chosenArea);
    }
}

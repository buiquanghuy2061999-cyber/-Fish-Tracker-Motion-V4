package com.fishtracker.motionv4;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 12;
    private static final int REQUEST_OVERLAY = 13;
    private MediaProjectionManager projectionManager;
    private TextView status;
    private TextView sensitivityLabel;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(30), pad, pad);
        root.setBackgroundColor(0xff101e30);

        TextView title = text("FISH TRACKER V4", 25, 0xff00ffd0);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView introduction = text("Chọn vùng bằng bút vẽ • Ước tính chuyển động cá • Không chặn chạm trong game", 15, 0xffffffff);
        introduction.setPadding(0, dp(12), 0, dp(18));
        root.addView(introduction);

        status = text("Bước 1: Nhấn BẮT ĐẦU và cho phép ghi màn hình.\nBước 2: Mở game, nhấn nút nổi VẼ VÙNG.\nBước 3: Vẽ quanh cá, nhấn XONG.", 16, 0xffffffff);
        root.addView(status);

        Button start = new Button(this);
        start.setText("BẮT ĐẦU ĐO");
        root.addView(start);
        start.setOnClickListener(v -> begin());

        Button select = new Button(this);
        select.setText("VẼ LẠI VÙNG ĐO");
        root.addView(select);
        select.setOnClickListener(v -> {
            if (!MotionService.isRunning) {
                status.setText("Hãy nhấn BẮT ĐẦU ĐO trước.");
            } else {
                Intent i = new Intent(this, MotionService.class);
                i.setAction(MotionService.ACTION_RESELECT);
                startService(i);
                status.setText("Quay lại game và chạm nút nổi VẼ VÙNG.");
            }
        });

        sensitivityLabel = text("Độ nhạy: Vừa", 16, 0xffffffff);
        sensitivityLabel.setPadding(0, dp(15), 0, 0);
        root.addView(sensitivityLabel);
        SeekBar sensitivity = new SeekBar(this);
        sensitivity.setMax(2);
        int saved = getSharedPreferences("tracker", MODE_PRIVATE).getInt("sensitivity", 1);
        sensitivity.setProgress(saved);
        updateSensitivityLabel(saved);
        root.addView(sensitivity);
        sensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateSensitivityLabel(progress);
                if (fromUser) getSharedPreferences("tracker", MODE_PRIVATE).edit().putInt("sensitivity", progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        TextView hint = text("Độ nhạy Cao giúp nhận chuyển động nhỏ nhưng cũng dễ bị ảnh động trong game gây nhiễu. Đơn vị px/s là tốc độ hình ảnh ước tính, không phải km/h.", 14, 0xffb5c8da);
        root.addView(hint);

        Button stop = new Button(this);
        stop.setText("DỪNG ĐO");
        root.addView(stop);
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, MotionService.class));
            status.setText("Đã gửi lệnh dừng. Có thể bắt đầu lại khi cần.");
        });
        setContentView(root);
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + .5f); }

    private void updateSensitivityLabel(int level) {
        String s = level == 0 ? "Thấp" : level == 2 ? "Cao" : "Vừa";
        sensitivityLabel.setText("Độ nhạy: " + s);
    }

    private void begin() {
        if (!Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(permission, REQUEST_OVERLAY);
            status.setText("Hãy cấp quyền hiển thị trên ứng dụng khác, sau đó nhấn BẮT ĐẦU ĐO một lần nữa.");
            return;
        }
        if (MotionService.isRunning) {
            status.setText("Đang đo. Quay lại game hoặc dùng VẼ LẠI VÙNG ĐO.");
            return;
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent i = new Intent(this, MotionService.class);
                i.putExtra(MotionService.EXTRA_CAPTURE_RESULT, resultCode);
                i.putExtra(MotionService.EXTRA_CAPTURE_DATA, data);
                startForegroundService(i);
                status.setText("Đã cấp quyền. Mở game rồi nhấn nút nổi VẼ VÙNG.");
            } else {
                status.setText("Chưa cho phép ghi màn hình. Nhấn BẮT ĐẦU ĐO để thử lại.");
            }
        }
    }
}

package com.fishtracker.motionv4;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Screen capture and game-touch-through overlay service for Android 8+. */
public final class MotionService extends Service {
    public static final String ACTION_RESELECT = "com.fishtracker.motionv4.RESELECT";
    public static final String EXTRA_CAPTURE_RESULT = "capture_result";
    public static final String EXTRA_CAPTURE_DATA = "capture_data";
    public static volatile boolean isRunning = false;
    private static final String TAG = "FishTrackerMotionV4";
    private static final String CHANNEL = "fish_motion";

    private WindowManager windowManager;
    private View overlay;
    private RegionPainter painter;
    private TextView speedView, stateView;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private volatile SelectedRegion activeRegion;
    private SampleGrid grid;
    private MotionAnalyzer analyzer;
    private long processedNs = 0;
    private int screenW, screenH, screenDpi;
    private boolean ending = false;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_RESELECT.equals(intent.getAction())) {
            if (isRunning) showBubble();
            return START_NOT_STICKY;
        }
        if (isRunning) return START_NOT_STICKY;
        if (intent == null || !intent.hasExtra(EXTRA_CAPTURE_DATA)) {
            stopSelf(); return START_NOT_STICKY;
        }
        ensureForeground();
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            refreshDimensions();
            captureThread = new HandlerThread("fish-motion-capture");
            captureThread.start();
            captureHandler = new Handler(captureThread.getLooper());
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            Intent permissionIntent = (Intent) intent.getParcelableExtra(EXTRA_CAPTURE_DATA);
            projection = manager.getMediaProjection(
                    intent.getIntExtra(EXTRA_CAPTURE_RESULT, -1), permissionIntent);
            if (projection == null) throw new IllegalStateException("Screen capture denied");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { mainHandler.post(() -> stopSelf()); }
            }, captureHandler);
            reader = makeReader(screenW, screenH);
            virtualDisplay = projection.createVirtualDisplay("Fish Motion V4",
                    screenW, screenH, screenDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, captureHandler);
            isRunning = true;
            showBubble();
            mainHandler.postDelayed(rotationMonitor, 1000);
        } catch (Exception error) {
            Log.e(TAG, "Capture initialization failed", error);
            Toast.makeText(this, "Không khởi động được chụp màn hình", Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void ensureForeground() {
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(
                CHANNEL, "Fish Tracker", NotificationManager.IMPORTANCE_LOW);
        notificationManager.createNotificationChannel(channel);
        Intent openApp = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openApp, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Fish Tracker Motion V4")
                .setContentText("Đang theo dõi chuyển động hình ảnh")
                .setOngoing(true)
                .setContentIntent(pendingIntent)
                .build();
        startForeground(1004, notification);
    }

    private void refreshDimensions() {
        DisplayMetrics dm = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        screenDpi = dm.densityDpi;
    }

    private ImageReader makeReader(int width, int height) {
        ImageReader result = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3);
        result.setOnImageAvailableListener(this::onImage, captureHandler);
        return result;
    }

    private final Runnable rotationMonitor = new Runnable() {
        @Override public void run() {
            if (!isRunning || ending) return;
            DisplayMetrics dm = new DisplayMetrics();
            windowManager.getDefaultDisplay().getRealMetrics(dm);
            if (dm.widthPixels != screenW || dm.heightPixels != screenH) {
                screenW = dm.widthPixels;
                screenH = dm.heightPixels;
                screenDpi = dm.densityDpi;
                activeRegion = null;
                showBubble();
                final int w = screenW, h = screenH, dpi = screenDpi;
                captureHandler.post(() -> {
                    try {
                        if (virtualDisplay != null) {
                            virtualDisplay.setSurface(null);
                            if (reader != null) {
                                reader.setOnImageAvailableListener(null, null);
                                reader.close();
                            }
                            reader = makeReader(w, h);
                            virtualDisplay.resize(w, h, dpi);
                            virtualDisplay.setSurface(reader.getSurface());
                            grid = null; analyzer = null; processedNs = 0;
                        }
                    } catch (Exception e) { Log.e(TAG, "Rotation resize failed", e); }
                });
                Toast.makeText(MotionService.this, "Màn hình đã xoay. Hãy vẽ lại vùng đo.", Toast.LENGTH_LONG).show();
            }
            mainHandler.postDelayed(this, 1000);
        }
    };

    private int dp(float value) {
        return (int) (getResources().getDisplayMetrics().density * value + 0.5f);
    }

    private GradientDrawable panel(int backgroundColor, int borderColor) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(backgroundColor);
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(2), borderColor);
        return bg;
    }

    private TextView label(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private WindowManager.LayoutParams params(int width, int height, int flags) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    private void clearOverlay() {
        if (overlay != null && windowManager != null) {
            try { windowManager.removeView(overlay); }
            catch (Exception ignored) { }
            overlay = null;
        }
        painter = null; speedView = null; stateView = null;
    }

    /** Small touchable launcher; game navigation is possible before selection. */
    private void showBubble() {
        if (ending || windowManager == null) return;
        activeRegion = null;
        clearOverlay();
        Button button = new Button(this);
        button.setText("✎ VẼ VÙNG");
        button.setTextSize(17);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setBackground(panel(0xff133d53, 0xff05edbb));
        button.setPadding(dp(14), dp(10), dp(14), dp(10));
        button.setOnClickListener(v -> showSelector());
        WindowManager.LayoutParams lp = params(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        lp.x = dp(8); lp.y = dp(65);
        overlay = button;
        windowManager.addView(button, lp);
    }

    /** Full-screen touchable freehand drawing surface, only shown during selection. */
    private void showSelector() {
        clearOverlay();
        FrameLayout root = new FrameLayout(this);
        painter = new RegionPainter();
        root.addView(painter, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.VERTICAL);
        tools.setPadding(dp(8), dp(8), dp(8), dp(8));
        tools.setBackgroundColor(0xec0a2231);
        TextView hint = label("Dùng ngón tay VẼ VÒNG quanh vùng cần đo", 15, Color.WHITE);
        tools.addView(hint);
        LinearLayout actions = new LinearLayout(this);
        tools.addView(actions);
        Button retry = new Button(this);
        retry.setText("VẼ LẠI");
        actions.addView(retry, new LinearLayout.LayoutParams(0, dp(52), 1));
        retry.setOnClickListener(v -> { if (painter != null) painter.clear(); });
        Button cancel = new Button(this);
        cancel.setText("HỦY");
        actions.addView(cancel, new LinearLayout.LayoutParams(0, dp(52), 1));
        cancel.setOnClickListener(v -> showBubble());
        Button finish = new Button(this);
        finish.setText("XONG");
        actions.addView(finish, new LinearLayout.LayoutParams(0, dp(52), 1));
        finish.setOnClickListener(v -> commitSelection());
        FrameLayout.LayoutParams toolParams = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(tools, toolParams);
        WindowManager.LayoutParams lp = params(-1, -1, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        overlay = root;
        windowManager.addView(root, lp);
    }

    private void commitSelection() {
        if (painter == null) return;
        SelectedRegion selection = painter.selectedRegion();
        if (selection == null) {
            Toast.makeText(this, "Hãy vẽ một vùng khép kín đủ lớn quanh cá.", Toast.LENGTH_SHORT).show();
            return;
        }
        activeRegion = selection;
        if (captureHandler != null) {
            captureHandler.post(() -> { grid = null; analyzer = null; processedNs = 0; });
        }
        showHud();
    }

    /** Non-touchable HUD with alpha below Android 12's untrusted touch-blocking opacity. */
    private void showHud() {
        clearOverlay();
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(10), dp(16), dp(10));
        card.setBackground(panel(0xff091828, 0xff00dba7));
        speedView = label("TỐC ĐỘ: -- px/s", 23, Color.WHITE);
        speedView.setTypeface(null, 1);
        speedView.setShadowLayer(2, 1, 1, Color.BLACK);
        card.addView(speedView);
        stateView = label("Đang học nền...", 15, 0xffffe09b);
        card.addView(stateView);
        WindowManager.LayoutParams lp = params(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        lp.x = dp(8); lp.y = dp(65);
        lp.alpha = 0.74f;
        overlay = card;
        windowManager.addView(card, lp);
    }

    private void updateHud(MotionAnalyzer.Result result) {
        mainHandler.post(() -> {
            if (speedView == null || stateView == null || activeRegion == null) return;
            if (result.state == MotionAnalyzer.State.LEARNING) {
                speedView.setText("TỐC ĐỘ: -- px/s");
                stateView.setText("Đang học nền, giữ nguyên màn hình...");
                stateView.setTextColor(0xffffdb8a);
            } else if (result.state == MotionAnalyzer.State.SEARCHING) {
                speedView.setText("TỐC ĐỘ: -- px/s");
                stateView.setText("Chưa phát hiện chuyển động cá");
                stateView.setTextColor(0xffffc66f);
            } else {
                speedView.setText(String.format(Locale.US, "TỐC ĐỘ: %.0f px/s", result.speedPixelsPerSecond));
                stateView.setText("Đang theo dõi chuyển động");
                stateView.setTextColor(0xff89ffd8);
            }
        });
    }

    private void onImage(ImageReader imageReader) {
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) return;
            SelectedRegion selection = activeRegion;
            if (selection == null || ending) return;
            long now = System.nanoTime();
            if (now - processedNs < 110_000_000L) return; // ~9 FPS, reduce heat.
            processedNs = now;
            if (grid == null || grid.selection != selection || analyzer == null) {
                grid = new SampleGrid(selection);
                int level = getSharedPreferences("tracker", MODE_PRIVATE).getInt("sensitivity", 1);
                analyzer = new MotionAnalyzer(grid.cols, grid.rows, grid.step, grid.inside, level);
            }
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int rowStride = plane.getRowStride(), pixelStride = plane.getPixelStride();
            int validW = image.getWidth(), validH = image.getHeight();
            int[] pixels = new int[grid.cols * grid.rows];
            for (int y = 0; y < grid.rows; y++) {
                int py = grid.top + y * grid.step;
                if (py >= validH) continue;
                for (int x = 0; x < grid.cols; x++) {
                    int n = y * grid.cols + x;
                    if (!grid.inside[n]) continue;
                    int px = grid.left + x * grid.step;
                    if (px >= validW) continue;
                    int offset = py * rowStride + px * pixelStride;
                    int red = buffer.get(offset) & 255;
                    int green = buffer.get(offset + 1) & 255;
                    int blue = buffer.get(offset + 2) & 255;
                    pixels[n] = (red << 16) | (green << 8) | blue;
                }
            }
            MotionAnalyzer.Result result = analyzer.update(pixels, now);
            updateHud(result);
        } catch (Exception e) {
            Log.e(TAG, "Image processing failed", e);
            mainHandler.post(() -> {
                if (stateView != null) {
                    stateView.setText("Lỗi xử lý ảnh - mở ứng dụng để thử lại");
                    stateView.setTextColor(0xffff7777);
                }
            });
        } finally {
            if (image != null) image.close();
        }
    }

    /** Immutable polygon defined in real screen (MediaProjection) pixel coordinates. */
    private static final class SelectedRegion {
        final float[] x, y;
        final Rect bounds;
        SelectedRegion(List<PointF> points, int offsetX, int offsetY, int maxW, int maxH) {
            x = new float[points.size()];
            y = new float[points.size()];
            float left = Float.POSITIVE_INFINITY, top = Float.POSITIVE_INFINITY;
            float right = Float.NEGATIVE_INFINITY, bottom = Float.NEGATIVE_INFINITY;
            for (int i = 0; i < points.size(); i++) {
                x[i] = points.get(i).x + offsetX;
                y[i] = points.get(i).y + offsetY;
                left = Math.min(left, x[i]); top = Math.min(top, y[i]);
                right = Math.max(right, x[i]); bottom = Math.max(bottom, y[i]);
            }
            bounds = new Rect(Math.max(0, (int) Math.floor(left)),
                    Math.max(0, (int) Math.floor(top)),
                    Math.min(maxW, (int) Math.ceil(right)),
                    Math.min(maxH, (int) Math.ceil(bottom)));
        }
        boolean contains(float px, float py) {
            boolean hit = false;
            int n = x.length;
            for (int i = 0, j = n - 1; i < n; j = i++) {
                if ((y[i] > py) != (y[j] > py)
                        && px < (x[j] - x[i]) * (py - y[i]) / (y[j] - y[i]) + x[i]) {
                    hit = !hit;
                }
            }
            return hit;
        }
    }

    /** Precomputed pixel grid and actual inside-the-drawn-polygon mask. */
    private final class SampleGrid {
        final SelectedRegion selection;
        final int left, top, step, cols, rows;
        final boolean[] inside;
        SampleGrid(SelectedRegion r) {
            selection = r;
            left = r.bounds.left; top = r.bounds.top;
            step = Math.max(2, Math.max((r.bounds.width() + 239) / 240, (r.bounds.height() + 359) / 360));
            cols = Math.max(1, (r.bounds.width() + step - 1) / step);
            rows = Math.max(1, (r.bounds.height() + step - 1) / step);
            inside = new boolean[cols * rows];
            for (int y = 0; y < rows; y++) {
                int py = top + y * step;
                for (int x = 0; x < cols; x++) {
                    int px = left + x * step;
                    inside[y * cols + x] = r.contains(px + .5f, py + .5f);
                }
            }
        }
    }

    private final class RegionPainter extends View {
        private final Paint brush = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final ArrayList<PointF> vertices = new ArrayList<>();
        private boolean drawing = false;
        RegionPainter() { super(MotionService.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

        void clear() { vertices.clear(); path.reset(); drawing = false; invalidate(); }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (!vertices.isEmpty()) {
                brush.setStyle(Paint.Style.FILL);
                brush.setColor(0x3300f5c8);
                if (!drawing) canvas.drawPath(path, brush);
                brush.setStyle(Paint.Style.STROKE);
                brush.setStrokeWidth(dp(5));
                brush.setStrokeJoin(Paint.Join.ROUND);
                brush.setStrokeCap(Paint.Cap.ROUND);
                brush.setColor(0xff00ffd0);
                canvas.drawPath(path, brush);
            }
            if (vertices.isEmpty()) {
                brush.setStyle(Paint.Style.FILL);
                brush.setTextSize(dp(23));
                brush.setColor(Color.WHITE);
                brush.setShadowLayer(3, 1, 1, Color.BLACK);
                canvas.drawText("✎ VẼ VÒNG quanh cá", dp(20), getHeight() / 2f, brush);
                brush.clearShadowLayer();
            }
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            float px = event.getX(), py = event.getY();
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    clear();
                    drawing = true;
                    addPoint(px, py, true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (drawing) {
                        for (int i=0; i<event.getHistorySize(); i++) {
                            addPoint(event.getHistoricalX(i), event.getHistoricalY(i), false);
                        }
                        addPoint(px, py, false);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (drawing) {
                        addPoint(px, py, false);
                        path.close(); drawing = false; invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    clear(); return true;
                default: return true;
            }
        }

        private void addPoint(float x, float y, boolean first) {
            if (!first && !vertices.isEmpty()) {
                PointF old = vertices.get(vertices.size() - 1);
                if (Math.hypot(x - old.x, y - old.y) < dp(3)) return;
            }
            if (vertices.size() >= 1200) return;
            vertices.add(new PointF(x, y));
            if (first) path.moveTo(x, y); else path.lineTo(x, y);
            invalidate();
        }

        SelectedRegion selectedRegion() {
            if (drawing || vertices.size() < 6) return null;
            int[] location = new int[2];
            getLocationOnScreen(location);
            SelectedRegion region = new SelectedRegion(vertices, location[0], location[1], screenW, screenH);
            if (region.bounds.width() < dp(36) || region.bounds.height() < dp(36)) return null;
            // Shoelace area rejects extremely thin scribbles.
            double twiceArea = 0;
            for (int i = 0; i < vertices.size(); i++) {
                PointF a = vertices.get(i), b = vertices.get((i + 1) % vertices.size());
                twiceArea += (double) a.x * b.y - (double) a.y * b.x;
            }
            if (Math.abs(twiceArea) < dp(36) * dp(36)) return null;
            return region;
        }
    }

    @Override public void onDestroy() {
        ending = true;
        isRunning = false;
        mainHandler.removeCallbacks(rotationMonitor);
        clearOverlay();
        activeRegion = null;
        if (captureHandler != null) {
            captureHandler.removeCallbacksAndMessages(null);
        }
        try { if (virtualDisplay != null) virtualDisplay.release(); }
        catch (Exception ignored) { }
        try { if (reader != null) reader.close(); }
        catch (Exception ignored) { }
        try { if (projection != null) projection.stop(); }
        catch (Exception ignored) { }
        if (captureThread != null) captureThread.quitSafely();
        super.onDestroy();
    }
}
